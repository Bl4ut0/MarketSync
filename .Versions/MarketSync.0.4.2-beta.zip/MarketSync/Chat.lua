-- =============================================================
-- MarketSync - Chat Module
-- Event handling for addon messages and chat queries
-- =============================================================

local PREFIX = MarketSync.PREFIX
local Debug = MarketSync.Debug
local FormatMoney = MarketSync.FormatMoney
local FormatAge = MarketSync.FormatAge

-- Guild sync commit timer: after 5s of no RES messages, commit the buffer
local guildSyncCommitTimer = nil
local GUILD_SYNC_IDLE_TIMEOUT = 5

-- ================================================================
-- EVENT FRAME
-- ================================================================
local frame = CreateFrame("Frame")
frame:RegisterEvent("CHAT_MSG_GUILD")
frame:RegisterEvent("CHAT_MSG_PARTY")
frame:RegisterEvent("CHAT_MSG_PARTY_LEADER")
frame:RegisterEvent("CHAT_MSG_RAID")
frame:RegisterEvent("CHAT_MSG_RAID_LEADER")
frame:RegisterEvent("CHAT_MSG_SAY")
frame:RegisterEvent("CHAT_MSG_YELL")
frame:RegisterEvent("CHAT_MSG_OFFICER")
frame:RegisterEvent("CHAT_MSG_WHISPER")
frame:RegisterEvent("CHAT_MSG_CHANNEL")
frame:RegisterEvent("CHAT_MSG_ADDON")

local function CompareVersions(v1, v2)
    local function parse(v)
        v = tostring(v)
        local major, minor, patch = v:match("(%d+)%.(%d+)%.?(%d*)")
        return tonumber(major) or 0, tonumber(minor) or 0, tonumber(patch) or 0
    end
    local m1, n1, p1 = parse(v1)
    local m2, n2, p2 = parse(v2)
    if m1 > m2 then return 1 end
    if m1 < m2 then return -1 end
    if n1 > n2 then return 1 end
    if n1 < n2 then return -1 end
    if p1 > p2 then return 1 end
    if p1 < p2 then return -1 end
    return 0
end

frame:SetScript("OnEvent", function(self, event, ...)
    -- ========================================
    -- ADDON MESSAGES (Sync Protocol)
    -- ========================================
    if event == "CHAT_MSG_ADDON" then
        local prefix, msg, channel, sender = ...
        if prefix ~= PREFIX then return end

        -- Strip realm suffix: sender comes as "Name-Realm" but UnitName returns just "Name"
        local senderName = sender and sender:match("^([^%-]+)") or sender
        if senderName == UnitName("player") then return end

        -- Extract sender's realm from "Name-Realm" format
        local senderRealm = sender and sender:match("%-(.+)$")
        local msgType, p1, p2, p3, p4, p5 = strsplit(";", msg)

        if msgType == "ADV" then
            local advRealm = p1
            local advScanDay = tonumber(p2) or 0
            local advItemCount = tonumber(p3) or 0
            local advVersion = p4 or "0.4.0-beta"
            
            if not MarketSync.myRealm then MarketSync.myRealm = GetNormalizedRealmName() or GetRealmName() end
            if advRealm ~= MarketSync.myRealm then
                Debug("Ignoring ADV from " .. senderName .. " (realm " .. tostring(advRealm) .. " != " .. MarketSync.myRealm .. ")")
                return
            end
            
            -- Version Compatibility Check
            local localVersion = C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata("MarketSync", "Version") or GetAddOnMetadata("MarketSync", "Version") or "0.0.0"
            local cmp = CompareVersions(advVersion, localVersion)
            if cmp > 0 then
                -- They are newer. We must disable our sync and warn the user to update.
                if MarketSyncDB and MarketSyncDB.PassiveSync then
                    MarketSyncDB.PassiveSync = false
                    print(string.format("|cFFFF0000[MarketSync]|r Sync Disabled! You are running an outdated version (v%s). %s is running v%s. Please update your addon.", localVersion, senderName, advVersion))
                    if MarketSync.LogNetworkEvent then
                        MarketSync.LogNetworkEvent(string.format("|cffff0000[Error]|r Outdated addon version! Disabled sync to prevent data corruption. (New version: v%s)", advVersion))
                    end
                end
                return
            elseif cmp < 0 then
                -- They are older. We just ignore their payload, but we explicitly list them in the Swarm Queue
                -- so the user can see who is running around with an outdated addon version.
                if MarketSync.UpdateSwarmUI then
                    MarketSync.UpdateSwarmUI(senderName, "|cff888888Legacy (v" .. advVersion .. ")|r")
                end
                
                if MarketSync.LogNetworkEvent then
                    MarketSync.LogNetworkEvent(string.format("Ignoring ADV from %s (Outdated version: v%s)", senderName, advVersion))
                end
                return
            end

            Debug("Received ADV from " .. senderName .. ": day=" .. advScanDay .. " items=" .. advItemCount)
            if MarketSync.LogNetworkEvent then
                MarketSync.LogNetworkEvent(string.format("Incoming |cff00ffff[ADV]|r from |cffffff00%s|r (Day %d, %d items, v%s)", senderName, advScanDay, advItemCount, advVersion))
            end
            if MarketSync.UpdateSwarmUI then MarketSync.UpdateSwarmUI(senderName, "Ready") end
            MarketSync.TrackSync(senderName, 0)
            local ourDay = MarketSync.GetMyLatestScanDay()
            local ourItemCount = 0
            if advScanDay == ourDay then
                ourItemCount = MarketSync.CountRecentItems(ourDay)
            end
            
            if advScanDay > ourDay or (advScanDay == ourDay and advItemCount > ourItemCount) then
                Debug("Their data is fresher (Day " .. advScanDay .. " vs " .. ourDay .. ", Items " .. advItemCount .. " vs " .. ourItemCount .. "), sending PULL")
                if MarketSync.LogNetworkEvent then
                    MarketSync.LogNetworkEvent(string.format("Data is fresher. Sending |cffff8800[PULL]|r request to Guild...", senderName, advScanDay, advItemCount))
                end
                
                -- We are going to receive data
                if MarketSync.UpdateSwarmUI then MarketSync.UpdateSwarmUI(UnitName("player"), "Receiving") end
                
                -- Begin guild sync session before pulling
                if MarketSync.BeginGuildSync then
                    MarketSync.BeginGuildSync()
                end
                MarketSync.SendPullRequest(ourDay)
            end

        elseif msgType == "PULL" then
            local pullRealm = p1
            local sinceDay = tonumber(p2) or 0
            if not MarketSync.myRealm then MarketSync.myRealm = GetNormalizedRealmName() or GetRealmName() end
            if pullRealm ~= MarketSync.myRealm then return end
            if not MarketSyncDB or not MarketSyncDB.PassiveSync then return end
            
            if MarketSync.LogNetworkEvent then
                MarketSync.LogNetworkEvent(string.format("Received |cffff8800[PULL]|r from |cffffff00%s|r (Since Day %d). Coordinating swarm...", senderName, sinceDay))
            end
            
            if MarketSync.UpdateSwarmUI then MarketSync.UpdateSwarmUI(senderName, "Receiving") end
            
            if MarketSync.SchedulePullResponse then
                MarketSync.SchedulePullResponse(sinceDay, senderName)
            end

        elseif msgType == "ACCEPT" then
            local acceptRealm = p1
            local sinceDay = tonumber(p2) or 0
            if not MarketSync.myRealm then MarketSync.myRealm = GetNormalizedRealmName() or GetRealmName() end
            if acceptRealm ~= MarketSync.myRealm then return end
            
            if MarketSync.RegisterPullAccept then
                MarketSync.RegisterPullAccept(sinceDay, senderName)
            end

        elseif msgType == "REQ" then
            local link = p1
            if not link then return end
            if senderRealm and MarketSync.myRealm and senderRealm ~= MarketSync.myRealm then return end
            local price = MarketSync.GetAuctionPrice(link)
            local age = MarketSync.GetAuctionAge(link)
            if price and age then
                local scanDay = MarketSync.GetCurrentScanDay() - age
                MarketSync.SendSyncResponse(link, price, scanDay, 0, "GUILD")
            end

        elseif msgType == "BRES" then
            local payloadStr = p1
            local day = tonumber(p2)
            if not day then return end
            if senderRealm and MarketSync.myRealm and senderRealm ~= MarketSync.myRealm then
                Debug("Ignoring BRES from cross-realm sender: " .. tostring(sender))
                return
            end
            
            local items = {strsplit(",", payloadStr)}
            for _, itemData in ipairs(items) do
                local idStr, priceStr, qtyStr = strsplit(":", itemData)
                local itemID = tonumber(idStr)
                local price = tonumber(priceStr)
                local quantity = tonumber(qtyStr) or 0
                
                if itemID and price then
                    local link = "item:" .. itemID .. ":0:0:0:0:0:0:0:0:0:0:0:0"
                    
                    MarketSync.UpdateLocalDB(link, price, day, quantity, senderName)
                end
            end
            MarketSync.RxCount = (MarketSync.RxCount or 0) + #items
            if MarketSync.UpdateSwarmUI then 
                MarketSync.UpdateSwarmUI(UnitName("player"), "Receiving")
                MarketSync.UpdateSwarmUI(senderName, "Sending")
            end
            
            if guildSyncCommitTimer then guildSyncCommitTimer:Cancel(); guildSyncCommitTimer = nil end
            guildSyncCommitTimer = C_Timer.NewTimer(GUILD_SYNC_IDLE_TIMEOUT, function()
                guildSyncCommitTimer = nil
                if MarketSync.UpdateSwarmUI then MarketSync.UpdateSwarmUI(UnitName("player"), nil) end
                if MarketSync.CommitGuildSync then
                    MarketSync.CommitGuildSync()
                end
                -- Invalidate scan cache because we just received new items!
                if MarketSyncDB then MarketSyncDB.CachedScanStats = nil end
            end)

        elseif msgType == "RES" then
            local link = p1
            local price = tonumber(p2)
            local day = tonumber(p3)
            local quantity = tonumber(p4) or 0
            if senderRealm and MarketSync.myRealm and senderRealm ~= MarketSync.myRealm then
                Debug("Ignoring RES from cross-realm sender: " .. tostring(sender))
                return
            end
            if link and price and day then
                MarketSync.RxCount = (MarketSync.RxCount or 0) + 1
                MarketSync.UpdateLocalDB(link, price, day, quantity, senderName)
                if MarketSync.UpdateSwarmUI then 
                    MarketSync.UpdateSwarmUI(UnitName("player"), "Receiving")
                    MarketSync.UpdateSwarmUI(senderName, "Sending")
                end

                -- Reset the idle commit timer on every RES received
                if guildSyncCommitTimer then guildSyncCommitTimer:Cancel(); guildSyncCommitTimer = nil end
                guildSyncCommitTimer = C_Timer.NewTimer(GUILD_SYNC_IDLE_TIMEOUT, function()
                    guildSyncCommitTimer = nil
                    if MarketSync.UpdateSwarmUI then MarketSync.UpdateSwarmUI(UnitName("player"), nil) end
                    if MarketSync.CommitGuildSync then
                        MarketSync.CommitGuildSync()
                    end
                    -- Invalidate scan cache because we just received new items!
                    if MarketSyncDB then MarketSyncDB.CachedScanStats = nil end
                end)
            end
        elseif msgType == "ERR" then
            local targetName = p1
            local crashKey = p2
            if targetName == UnitName("player") then
                if MarketSync.LogNetworkEvent then
                    MarketSync.LogNetworkEvent(string.format("|cffff0000[Error]|r Sync failed. %s's database contains a corrupt entry at dbKey: %s", senderName, tostring(crashKey)))
                end
                if MarketSync.UpdateSwarmUI then
                    MarketSync.UpdateSwarmUI(senderName, "|cffff0000Error|r")
                    MarketSync.UpdateSwarmUI(UnitName("player"), nil)
                end
                if guildSyncCommitTimer then
                    guildSyncCommitTimer:Cancel()
                    guildSyncCommitTimer = nil
                end
            end
        end
        return
    end

    -- ========================================
    -- CHAT QUERIES ("? [Item Link]")
    -- ========================================
    local msg, sender, _, _, _, _, _, channelID = ...
    
    -- 1. Anti-Flood: Monitor for existing replies
    -- If we see "[Item Link]: 1g 20s" from someone else, cancel our pending reply for that item.
    local replyLink = msg:match("(|c%x+|Hitem:.-|h%[.-%]|h|r):")
    if replyLink and sender ~= UnitName("player") then
        local itemID = tonumber(replyLink:match("item:(%d+)"))
        if itemID and MarketSync.pendingQueries and MarketSync.pendingQueries[itemID] then
            MarketSync.pendingQueries[itemID] = nil -- Cancel our pending reply
            Debug("Suppressed reply for " .. itemID .. " (beaten by " .. sender .. ")")
        end
        return
    end

    -- 2. Handle Incoming Queries
    if msg:find("^%?") then
        -- Respect the user's setting to disable auto-replies
        if MarketSyncDB and not MarketSyncDB.EnableChatPriceCheck then return end

        local link = msg:match("(|c%x+|Hitem:.-|h%[.-%]|h|r)")
        if link then
            local itemID = tonumber(link:match("item:(%d+)"))
            if not itemID then return end

            -- Init pending table if needed
            if not MarketSync.pendingQueries then MarketSync.pendingQueries = {} end

            -- Ignore if we already have a pending reply for this item (debounce)
            if MarketSync.pendingQueries[itemID] then return end

            -- Check if we even have data first
            local price = MarketSync.GetAuctionPrice(link)
            if not price then return end -- No data, no reply

            -- Start the lottery!
            MarketSync.pendingQueries[itemID] = true
            local delay = 0.5 + (math.random() * 1.5) -- 0.5s to 2.0s random delay

            C_Timer.After(delay, function()
                -- If the flag was cleared by the monitor above, abort.
                if not MarketSync.pendingQueries[itemID] then return end
                MarketSync.pendingQueries[itemID] = nil -- Clear flag

                -- Re-check price (just in case, though unlikely to change in 1s)
                local age = MarketSync.GetAuctionAge(link)
                local ageStr = FormatAge(age)
                local metaStr = ""

                -- We can try to get metadata, but AuctionatorDB is synchronous usually?
                -- If DBKeyFromLink is async, this might be Tricky inside a Timer callback context? 
                -- Actually GetAuctionPrice is direct. DBKeyFromLink uses a callback or returns keys?
                -- Auctionator.Utilities.DBKeyFromLink(link, callback) ...
                -- Let's keep it simple for now to ensure reliability inside the timer.
                
                local output = string.format("%s: %s (Age: %s)", link, FormatMoney(price), ageStr)

                -- Determine channel to reply in
                local replyChannel = "SAY"
                local target = nil
                
                -- Map event to reply channel
                if event == "CHAT_MSG_GUILD" then replyChannel = "GUILD"
                elseif event == "CHAT_MSG_PARTY" or event == "CHAT_MSG_PARTY_LEADER" then replyChannel = "PARTY"
                elseif event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then replyChannel = "RAID"
                elseif event == "CHAT_MSG_YELL" then replyChannel = "YELL"
                elseif event == "CHAT_MSG_OFFICER" then replyChannel = "OFFICER"
                elseif event == "CHAT_MSG_WHISPER" then
                    replyChannel = "WHISPER"
                    target = sender
                elseif event == "CHAT_MSG_CHANNEL" then
                    replyChannel = "CHANNEL"
                    target = channelID
                end

                C_ChatInfo.SendChatMessage(output, replyChannel, nil, target)
            end)
        end
    end
end)


