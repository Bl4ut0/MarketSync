# Auctionator Announcer

Auctionator Announcer is a World of Warcraft addon that enhances Auctionator by allowing guild members to share price data and check prices via chat commands.

## Features
*   **Chat Price Check**: Type `? [Item Link]` in chat to instantly announce the item's price and data age.
*   **Peer-to-Peer Sync**: Automatically requests fresher data from guildmates when you check an item.
*   **Bulk Sync**: Manually broadcast your latest scan data to the guild.
*   **Diagnostic Tools**: Search your local database and track sync calculations.
*   **User Blocking**: Prevent specific users from syncing data to you.

## Dependencies
*   **Auctionator** (Required)

## Installation
1.  Ensure **Auctionator** is installed.
2.  Copy the `AuctionatorAnnouncer` folder to your WoW AddOns directory:
    *   Classic/TBC/Era: `_classic_\Interface\AddOns\`
    *   Retail: `_retail_\Interface\AddOns\`
3.  Reload your UI.

## Usage

### Price Checking
In **any** chat channel (Say, Party, Guild, Raid, Yell, Officer, Whisper, General, Trade, etc.), type `? ` followed by the item link.
*   **Example**: `? [Linen Cloth]`
*   The addon will reply with: `[Linen Cloth]: 50s (Age: Today) (S: PlayerName @ 12:00)`

### Slash Commands
*   `/aucann sync`: Broadcasts all items you scannned **today** to your guild. (Use this after running a Full Scan).
*   `/aucann search [name]`: Searches your local Auctionator database for an item name.
    *   Example: `/aucann search black lotus`
*   `/aucann stats`: Opens the Settings Panel to view sync statistics and manage blocked users.
*   `/aucann block [name]`: Blocks a player from sending you data.
*   `/aucann unblock [name]`: Unblocks a player.

### Settings
Access the configuration via **Game Menu > Options > AddOns > Auctionator Announcer**.
*   **Passive Sync**: Toggle "Enable Passive Background Sync" to slowly broadcast your data to guildmates (1 item ~10s).
*   **Sync Statistics**: View how much data you've received from guildmates.
*   **Block List**: Manage blocked users via the UI.
