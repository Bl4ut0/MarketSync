-- =============================================================
-- MarketSync - Notifications Module
-- Threshold alerts + Auctionator shopping list import
-- =============================================================

local ADDON_CALLER_ID = "MarketSync"

local function NormalizeScope(scope)
    if scope == "main" or scope == "neutral" or scope == "all" then
        return scope
    end
    return "all"
end

local function NormalizeVariantMode(mode)
    if mode == "exact_key" or mode == "any_suffix" then
        return mode
    end
    return "any_suffix"
end

local function BuildRequestID(matchType, matchValue, scope)
    local safe = tostring(matchValue or ""):gsub("[^%w:_%-]", "_")
    return string.format("%s:%s:%s", tostring(matchType or "name"), safe, NormalizeScope(scope))
end

local function GetRequestState(realmDB, requestID)
    if not realmDB.NotificationState[requestID] then
        realmDB.NotificationState[requestID] = {
            lastAlertAt = 0,
            lastAlertPrice = 0,
            armed = true,
        }
    end
    return realmDB.NotificationState[requestID]
end

local function ResolveItemName(itemID)
    if not itemID then return nil end
    local cache = MarketSyncDB and MarketSyncDB.ItemInfoCache and MarketSyncDB.ItemInfoCache[itemID]
    if cache and cache.n then return cache.n end
    local name = C_Item and C_Item.GetItemInfo and C_Item.GetItemInfo(itemID)
    return name
end

local function AlertNotification(req, state, itemName, price)
    local threshold = req.thresholdCopper or 0
    local scopeText = (req.scope == "neutral") and "Neutral" or ((req.scope == "main") and "Main" or "Any")
    local msg = string.format(
        "|cFF00FF00[MarketSync Alert]|r %s dropped to %s (threshold %s, scope: %s).",
        itemName or req.displayName or req.matchValue or "Tracked item",
        MarketSync.FormatMoney(price),
        MarketSync.FormatMoney(threshold),
        scopeText
    )
    print(msg)

    if RaidNotice_AddMessage and RaidWarningFrame then
        RaidNotice_AddMessage(RaidWarningFrame, msg:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""), ChatTypeInfo["RAID_WARNING"])
    end

    if MarketSyncDB and MarketSyncDB.EnableNotificationSounds and PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then
        PlaySound(SOUNDKIT.RAID_WARNING, "Master")
    end
end

function MarketSync.UpsertNotificationRequest(req)
    local realmDB = MarketSync.GetRealmDB()
    local matchType = req.matchType or "name"
    local matchValue = req.matchValue or req.displayName
    if not matchValue then return nil end

    local scope = NormalizeScope(req.scope)
    local requestID = req.id or BuildRequestID(matchType, matchValue, scope)
    local now = time()

    local existing = realmDB.NotificationRequests[requestID] or {}
    existing.id = requestID
    existing.matchType = matchType
    existing.matchValue = matchValue
    existing.displayName = req.displayName or existing.displayName or tostring(matchValue)
    existing.thresholdCopper = tonumber(req.thresholdCopper) or existing.thresholdCopper or 0
    existing.scope = scope
    existing.variantMode = NormalizeVariantMode(req.variantMode)
    existing.cooldownSec = tonumber(req.cooldownSec) or existing.cooldownSec or (realmDB.NotificationSettings.defaultCooldownSec or 300)
    existing.enabled = (req.enabled == nil) and (existing.enabled ~= false) or not not req.enabled
    existing.createdAt = existing.createdAt or now
    existing.quantityHint = tonumber(req.quantityHint) or existing.quantityHint
    existing.importSource = req.importSource or existing.importSource

    realmDB.NotificationRequests[requestID] = existing
    GetRequestState(realmDB, requestID)
    return existing
end

function MarketSync.DeleteNotificationRequest(requestID)
    local realmDB = MarketSync.GetRealmDB()
    realmDB.NotificationRequests[requestID] = nil
    realmDB.NotificationState[requestID] = nil
end

function MarketSync.ListNotificationRequests()
    local realmDB = MarketSync.GetRealmDB()
    local out = {}
    for _, req in pairs(realmDB.NotificationRequests) do
        table.insert(out, req)
    end
    table.sort(out, function(a, b)
        return (a.displayName or a.id or ""):lower() < (b.displayName or b.id or ""):lower()
    end)
    return out
end

local function RequestMatches(req, dbKey, itemID, itemName)
    if req.matchType == "dbKey" then
        if req.variantMode == "any_suffix" then
            local reqID = MarketSync.ParseItemIDFromDBKey(req.matchValue)
            return reqID and itemID and reqID == itemID
        end
        return tostring(req.matchValue) == tostring(dbKey)
    elseif req.matchType == "itemID" then
        return tonumber(req.matchValue) and itemID and tonumber(req.matchValue) == itemID
    else
        if not itemName then return false end
        return itemName:lower() == tostring(req.matchValue):lower()
    end
end

local function ScopeAllows(reqScope, eventScope)
    reqScope = NormalizeScope(reqScope)
    eventScope = NormalizeScope(eventScope)
    if reqScope == "all" then return true end
    if eventScope == "all" then return true end
    return reqScope == eventScope
end

function MarketSync.EvaluateNotificationsForRecord(dbKey, price, eventScope, sourceName, explicitName, explicitItemID)
    local realmDB = MarketSync.GetRealmDB()
    if not realmDB or not realmDB.NotificationRequests then return 0 end
    if not price or price <= 0 then return 0 end

    local itemID = explicitItemID or MarketSync.ParseItemIDFromDBKey(dbKey)
    local itemName = explicitName or ResolveItemName(itemID)
    local now = time()
    local alerted = 0
    local settings = realmDB.NotificationSettings or {}
    local rearmPct = tonumber(settings.rearmBufferPct) or 5
    local rearmAfterSec = tonumber(settings.rearmAfterSec) or 1800

    for id, req in pairs(realmDB.NotificationRequests) do
        if req.enabled ~= false and ScopeAllows(req.scope, eventScope) and RequestMatches(req, dbKey, itemID, itemName) then
            local threshold = tonumber(req.thresholdCopper) or 0
            if threshold > 0 then
                local state = GetRequestState(realmDB, id)
                local cooldown = tonumber(req.cooldownSec) or (settings.defaultCooldownSec or 300)
                local sinceAlert = now - (state.lastAlertAt or 0)
                local rearmThreshold = math.floor(threshold * (1 + (rearmPct / 100)))

                if state.armed == false then
                    if price > rearmThreshold or sinceAlert >= rearmAfterSec then
                        state.armed = true
                    end
                end

                if state.armed ~= false and price <= threshold and sinceAlert >= cooldown then
                    state.lastAlertAt = now
                    state.lastAlertPrice = price
                    state.armed = false
                    AlertNotification(req, state, itemName, price)
                    alerted = alerted + 1
                end
            end
        end
    end

    return alerted
end

function MarketSync.GetAuctionatorShoppingListNames()
    if not Auctionator or not Auctionator.Shopping or not Auctionator.Shopping.ListManager then
        return {}
    end
    local names = {}
    for i = 1, Auctionator.Shopping.ListManager:GetCount() do
        local list = Auctionator.Shopping.ListManager:GetByIndex(i)
        if list and list.GetName then
            table.insert(names, list:GetName())
        end
    end
    table.sort(names, function(a, b) return tostring(a):lower() < tostring(b):lower() end)
    return names
end

function MarketSync.ImportNotificationRequestsFromAuctionator(listNames, options)
    options = options or {}
    if not Auctionator or not Auctionator.API or not Auctionator.API.v1 then
        return 0, "Auctionator API unavailable"
    end

    local names = listNames
    if not names or #names == 0 then
        names = MarketSync.GetAuctionatorShoppingListNames()
    end
    if not names or #names == 0 then
        return 0, "No Auctionator lists found"
    end

    local imported = 0
    local threshold = tonumber(options.thresholdCopper)
    local enabledDefault = options.enabledDefault

    for _, listName in ipairs(names) do
        local okItems, itemsOrErr = pcall(Auctionator.API.v1.GetShoppingListItems, ADDON_CALLER_ID, listName)
        if okItems and type(itemsOrErr) == "table" then
            for _, raw in ipairs(itemsOrErr) do
                local okTerm, term = pcall(Auctionator.API.v1.ConvertFromSearchString, ADDON_CALLER_ID, raw)
                if okTerm and type(term) == "table" and type(term.searchString) == "string" and term.searchString ~= "" then
                    local reqID = BuildRequestID("name", term.searchString:lower(), options.scope or "all")
                    local req = MarketSync.UpsertNotificationRequest({
                        id = reqID,
                        matchType = "name",
                        matchValue = term.searchString:lower(),
                        displayName = term.searchString,
                        thresholdCopper = threshold or 0,
                        scope = options.scope or "all",
                        variantMode = "any_suffix",
                        cooldownSec = tonumber(options.cooldownSec) or nil,
                        enabled = (enabledDefault ~= nil) and enabledDefault or (threshold and threshold > 0),
                        quantityHint = term.quantity,
                        importSource = listName,
                    })
                    if req then
                        imported = imported + 1
                    end
                end
            end
        end
    end

    return imported
end
