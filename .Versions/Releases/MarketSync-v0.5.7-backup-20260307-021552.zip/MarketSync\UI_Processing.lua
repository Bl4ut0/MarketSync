-- =============================================================
-- MarketSync - Processing Panel UI
-- Reverse breakdown + crafting profitability + export
-- =============================================================

local function BuildDropdown(frameName, parent, width, initFunc)
    local dd = CreateFrame("Frame", frameName, parent, "UIDropDownMenuTemplate")
    dd:SetWidth(width)
    UIDropDownMenu_SetWidth(dd, width)
    dd._initFunc = initFunc
    UIDropDownMenu_Initialize(dd, initFunc)
    return dd
end

local function ReadNumber(editBox, defaultVal)
    local v = tonumber((editBox:GetText() or ""):gsub(",", ""))
    if not v then return defaultVal end
    return v
end

function MarketSync.CreateProcessingPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints(parent)
    panel:Hide()

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 70, -52)
    title:SetText("|cffffd700Processing Arbitrage|r")

    local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    sub:SetText("|cff888888Find items worth prospecting/milling/disenchanting and export directly to Auctionator.|r")

    local targetLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    targetLabel:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 0, -18)
    targetLabel:SetText("Target Material")

    panel.selectedTargetID = nil
    panel.selectedProcess = nil
    panel.selectedProfession = "Alchemy"
    panel.lastMode = nil
    panel.lastArbitrageResults = {}
    panel.lastCraftResults = {}

    local targetDropdown
    targetDropdown = BuildDropdown("MarketSyncProcessingTargetDropdown", panel, 220, function(self, level)
        local info = UIDropDownMenu_CreateInfo()
        info.text = "Select material..."
        info.func = function()
            panel.selectedTargetID = nil
            UIDropDownMenu_SetText(targetDropdown, "Select material...")
        end
        UIDropDownMenu_AddButton(info)
        for _, t in ipairs(MarketSync.GetProcessingTargets and MarketSync.GetProcessingTargets() or {}) do
            local opt = UIDropDownMenu_CreateInfo()
            opt.text = string.format("%s (%d)", t.name or ("Item " .. tostring(t.itemID)), t.itemID)
            opt.func = function()
                panel.selectedTargetID = t.itemID
                UIDropDownMenu_SetText(targetDropdown, opt.text)
            end
            UIDropDownMenu_AddButton(opt)
        end
    end)
    targetDropdown:SetPoint("TOPLEFT", targetLabel, "BOTTOMLEFT", -16, -4)

    local processLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    processLabel:SetPoint("TOPLEFT", targetDropdown, "BOTTOMLEFT", 16, -8)
    processLabel:SetText("Process")

    local processOptions = { "ALL", "PROSPECT", "MILL", "DISENCHANT" }
    local processDropdown
    processDropdown = BuildDropdown("MarketSyncProcessingTypeDropdown", panel, 220, function(self, level)
        for _, p in ipairs(processOptions) do
            local opt = UIDropDownMenu_CreateInfo()
            opt.text = p
            opt.func = function()
                panel.selectedProcess = (p == "ALL") and nil or p
                UIDropDownMenu_SetText(processDropdown, p)
            end
            UIDropDownMenu_AddButton(opt)
        end
    end)
    processDropdown:SetPoint("TOPLEFT", processLabel, "BOTTOMLEFT", -16, -4)
    UIDropDownMenu_SetText(processDropdown, "ALL")

    local marginLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    marginLabel:SetPoint("TOPLEFT", processDropdown, "BOTTOMLEFT", 16, -8)
    marginLabel:SetText("Margin %")

    local marginBox = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    marginBox:SetSize(60, 20)
    marginBox:SetPoint("LEFT", marginLabel, "RIGHT", 10, 0)
    marginBox:SetAutoFocus(false)
    marginBox:SetNumeric(true)
    marginBox:SetText("10")

    local craftProfLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    craftProfLabel:SetPoint("TOPLEFT", marginLabel, "BOTTOMLEFT", 0, -20)
    craftProfLabel:SetText("Craft Profession")

    local professionOptions = { "Alchemy", "Enchanting" }
    local professionDropdown
    professionDropdown = BuildDropdown("MarketSyncCraftProfDropdown", panel, 220, function(self, level)
        for _, p in ipairs(professionOptions) do
            local opt = UIDropDownMenu_CreateInfo()
            opt.text = p
            opt.func = function()
                panel.selectedProfession = p
                UIDropDownMenu_SetText(professionDropdown, p)
            end
            UIDropDownMenu_AddButton(opt)
        end
    end)
    professionDropdown:SetPoint("TOPLEFT", craftProfLabel, "BOTTOMLEFT", -16, -4)
    UIDropDownMenu_SetText(professionDropdown, panel.selectedProfession)

    local minMarginLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    minMarginLabel:SetPoint("TOPLEFT", professionDropdown, "BOTTOMLEFT", 16, -8)
    minMarginLabel:SetText("Min Craft Margin (g)")

    local minMarginGoldBox = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    minMarginGoldBox:SetSize(80, 20)
    minMarginGoldBox:SetPoint("LEFT", minMarginLabel, "RIGHT", 10, 0)
    minMarginGoldBox:SetAutoFocus(false)
    minMarginGoldBox:SetNumeric(true)
    minMarginGoldBox:SetText("5")

    local btnFindTarget = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnFindTarget:SetSize(130, 22)
    btnFindTarget:SetPoint("TOPLEFT", minMarginLabel, "BOTTOMLEFT", 0, -18)
    btnFindTarget:SetText("Find by Material")

    local btnFindProcess = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnFindProcess:SetSize(130, 22)
    btnFindProcess:SetPoint("LEFT", btnFindTarget, "RIGHT", 8, 0)
    btnFindProcess:SetText("Find by Process")

    local btnFindCrafts = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnFindCrafts:SetSize(130, 22)
    btnFindCrafts:SetPoint("TOPLEFT", btnFindTarget, "BOTTOMLEFT", 0, -8)
    btnFindCrafts:SetText("Find Crafts")

    local btnExport = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnExport:SetSize(130, 22)
    btnExport:SetPoint("LEFT", btnFindCrafts, "RIGHT", 8, 0)
    btnExport:SetText("Export to Auctionator")

    local btnTrack = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnTrack:SetSize(130, 22)
    btnTrack:SetPoint("LEFT", btnExport, "RIGHT", 8, 0)
    btnTrack:SetText("Track Results")

    local resultsPanel = CreateFrame("Frame", nil, panel, "BackdropTemplate")
    resultsPanel:SetPoint("TOPLEFT", targetDropdown, "TOPRIGHT", 24, 2)
    resultsPanel:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -24, 34)
    resultsPanel.backdropInfo = {
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    }
    resultsPanel:ApplyBackdrop()
    resultsPanel:SetBackdropColor(0, 0, 0, 0.5)

    local resultsTitle = resultsPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    resultsTitle:SetPoint("TOPLEFT", 10, -10)
    resultsTitle:SetText("Results")

    local resultsScroll = CreateFrame("ScrollingMessageFrame", nil, resultsPanel)
    resultsScroll:SetPoint("TOPLEFT", 10, -30)
    resultsScroll:SetPoint("BOTTOMRIGHT", -10, 10)
    resultsScroll:SetFontObject("GameFontHighlightSmall")
    resultsScroll:SetJustifyH("LEFT")
    resultsScroll:SetFading(false)
    resultsScroll:SetMaxLines(1000)
    resultsScroll:EnableMouseWheel(true)
    resultsScroll:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then self:ScrollUp() else self:ScrollDown() end
    end)
    panel.resultsScroll = resultsScroll

    local function RenderArbitrage(results, modeLabel)
        panel.lastArbitrageResults = results or {}
        panel.lastMode = "arbitrage"
        resultsScroll:Clear()
        resultsTitle:SetText("Results - " .. (modeLabel or "Arbitrage"))
        if not results or #results == 0 then
            resultsScroll:AddMessage("|cffff8800No opportunities found (or missing market prices).|r")
            return
        end
        for i, r in ipairs(results) do
            if i > 150 then break end
            local live = (r.livePrice and r.livePrice > 0) and MarketSync.FormatMoney(r.livePrice) or "N/A"
            local maxBuy = MarketSync.FormatMoney(r.maxBuyPerUnit or 0)
            local ev = r.evPerUnit and MarketSync.FormatMoney(r.evPerUnit) or (r.targetPrice and MarketSync.FormatMoney(math.floor((r.targetPrice or 0) * (r.expectedTarget or 0))) or "N/A")
            local flag = r.profitable and "|cff00ff00BUY|r" or "|cffff4444SKIP|r"
            resultsScroll:AddMessage(string.format(
                "%s |cffffff00%s|r [%s] EV %s | Max %s | Live %s",
                flag, r.inputName or ("Item " .. tostring(r.inputItemID)), r.processType or "N/A", ev, maxBuy, live
            ))
        end
    end

    local function RenderCrafts(results)
        panel.lastCraftResults = results or {}
        panel.lastMode = "craft"
        resultsScroll:Clear()
        resultsTitle:SetText("Results - Profitable Crafts")
        if not results or #results == 0 then
            resultsScroll:AddMessage("|cffff8800No profitable crafts found for selected filters.|r")
            return
        end
        for i, r in ipairs(results) do
            if i > 150 then break end
            resultsScroll:AddMessage(string.format(
                "|cff00ff00%s|r | Cost %s | Revenue %s | Margin %s",
                r.recipeName or "Recipe",
                MarketSync.FormatMoney(r.craftCost or 0),
                MarketSync.FormatMoney(r.revenue or 0),
                MarketSync.FormatMoney(r.margin or 0)
            ))
        end
    end

    btnFindTarget:SetScript("OnClick", function()
        if not panel.selectedTargetID then
            resultsScroll:Clear()
            resultsScroll:AddMessage("|cffff8800Select a target material first.|r")
            return
        end
        local margin = ReadNumber(marginBox, 10)
        local results = MarketSync.FindArbitrageByTarget and MarketSync.FindArbitrageByTarget(panel.selectedTargetID, margin) or {}
        RenderArbitrage(results, "Target Material")
    end)

    btnFindProcess:SetScript("OnClick", function()
        local margin = ReadNumber(marginBox, 10)
        local results = MarketSync.FindArbitrageByProcess and MarketSync.FindArbitrageByProcess(panel.selectedProcess, margin) or {}
        RenderArbitrage(results, panel.selectedProcess or "ALL")
    end)

    btnFindCrafts:SetScript("OnClick", function()
        local minGold = ReadNumber(minMarginGoldBox, 5)
        local minCopper = math.floor(minGold * 10000)
        local results = MarketSync.FindProfitableCrafts and MarketSync.FindProfitableCrafts(panel.selectedProfession, minCopper) or {}
        RenderCrafts(results)
    end)

    btnExport:SetScript("OnClick", function()
        if panel.lastMode == "craft" then
            local ok, info = MarketSync.ExportCraftMatsToAuctionator and MarketSync.ExportCraftMatsToAuctionator(panel.lastCraftResults, nil)
            if ok then
                print(string.format("|cFF00FF00[MarketSync]|r Exported %d crafting materials to Auctionator list.", tonumber(info) or 0))
            else
                print("|cFFFF0000[MarketSync]|r Craft export failed: " .. tostring(info))
            end
        else
            local ok, info = MarketSync.ExportArbitrageToAuctionator and MarketSync.ExportArbitrageToAuctionator(panel.lastArbitrageResults, nil)
            if ok then
                print(string.format("|cFF00FF00[MarketSync]|r Exported %d arbitrage entries to Auctionator list.", tonumber(info) or 0))
            else
                print("|cFFFF0000[MarketSync]|r Arbitrage export failed: " .. tostring(info))
            end
        end
    end)

    btnTrack:SetScript("OnClick", function()
        local tracked = 0
        if panel.lastMode == "arbitrage" then
            for i, r in ipairs(panel.lastArbitrageResults or {}) do
                if i > 40 then break end
                local keyValue = tostring(r.inputItemID or "")
                if keyValue ~= "" and (r.maxBuyPerUnit or 0) > 0 then
                    local req = MarketSync.UpsertNotificationRequest and MarketSync.UpsertNotificationRequest({
                        matchType = "itemID",
                        matchValue = tonumber(keyValue),
                        displayName = r.inputName,
                        thresholdCopper = r.maxBuyPerUnit,
                        scope = "all",
                        variantMode = "any_suffix",
                        enabled = true,
                    })
                    if req then tracked = tracked + 1 end
                end
            end
        end
        print(string.format("|cFF00FF00[MarketSync]|r Added/updated %d notification requests from current results.", tracked))
    end)

    panel:SetScript("OnShow", function()
        resultsScroll:Clear()
        resultsScroll:AddMessage("|cff888888Pick a mode and click one of the finder buttons.|r")
        if UIDropDownMenu_Initialize then
            UIDropDownMenu_Initialize(targetDropdown, targetDropdown._initFunc)
            UIDropDownMenu_Initialize(processDropdown, processDropdown._initFunc)
            UIDropDownMenu_Initialize(professionDropdown, professionDropdown._initFunc)
        end
    end)

    return panel
end
