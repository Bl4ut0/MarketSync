-- =============================================================
-- MarketSync - Processing Arbitrage Module
-- EV calculator + Auctionator shopping list export
-- =============================================================

local CALLER_ID = "MarketSync"

-- Foundation dataset (expand over time)
MarketSync.ProcessingData = MarketSync.ProcessingData or {
    -- Fel Iron Ore
    [23424] = {
        type = "PROSPECT",
        stackSize = 5,
        yields = {
            { itemID = 23077, prob = 0.25, min = 1, max = 2 }, -- Blood Garnet
            { itemID = 21929, prob = 0.25, min = 1, max = 2 }, -- Flame Spessarite
            { itemID = 23112, prob = 0.25, min = 1, max = 2 }, -- Golden Draenite
            { itemID = 23117, prob = 0.25, min = 1, max = 2 }, -- Azure Moonstone
        },
    },
    -- Adamantite Ore
    [23425] = {
        type = "PROSPECT",
        stackSize = 5,
        yields = {
            { itemID = 23436, prob = 0.20, min = 1, max = 2 }, -- Living Ruby
            { itemID = 23437, prob = 0.20, min = 1, max = 2 }, -- Talasite
            { itemID = 23438, prob = 0.20, min = 1, max = 2 }, -- Star of Elune
            { itemID = 23439, prob = 0.20, min = 1, max = 2 }, -- Noble Topaz
            { itemID = 23440, prob = 0.20, min = 1, max = 2 }, -- Dawnstone
        },
    },
    -- Netherbloom
    [22791] = {
        type = "MILL",
        stackSize = 5,
        yields = {
            { itemID = 39334, prob = 0.90, min = 2, max = 4 }, -- Dusky Pigment
            { itemID = 43103, prob = 0.10, min = 1, max = 2 }, -- Verdant Pigment
        },
    },
}

MarketSync.CraftingData = MarketSync.CraftingData or {
    Alchemy = {
        {
            name = "Flask of Mighty Restoration",
            outputItemID = 22861,
            outputQty = 1,
            mats = {
                { itemID = 22790, qty = 7 }, -- Ancient Lichen
                { itemID = 22787, qty = 3 }, -- Ragveil
                { itemID = 31672, qty = 1 }, -- Mok'Nathal Shortribs
            },
        },
    },
    Enchanting = {
        {
            name = "Large Prismatic Shard (craft proxy)",
            outputItemID = 22449,
            outputQty = 1,
            mats = {
                { itemID = 22445, qty = 3 }, -- Arcane Dust
                { itemID = 22446, qty = 1 }, -- Planar Essence
            },
        },
    },
}

local function GetItemName(itemID)
    if not itemID then return nil end
    local cached = MarketSyncDB and MarketSyncDB.ItemInfoCache and MarketSyncDB.ItemInfoCache[itemID]
    if cached and cached.n then return cached.n end
    local name = C_Item and C_Item.GetItemInfo and C_Item.GetItemInfo(itemID)
    if name and MarketSyncDB and MarketSyncDB.ItemInfoCache then
        MarketSyncDB.ItemInfoCache[itemID] = MarketSyncDB.ItemInfoCache[itemID] or {}
        MarketSyncDB.ItemInfoCache[itemID].n = name
    end
    return name
end

local function GetPriceByItemID(itemID)
    if not itemID or not Auctionator or not Auctionator.API or not Auctionator.API.v1 then
        return nil
    end
    local ok, price = pcall(Auctionator.API.v1.GetAuctionPriceByItemID, CALLER_ID, itemID)
    if ok and type(price) == "number" and price > 0 then
        return price
    end
    return nil
end

local function ExpectedYield(y)
    local minV = tonumber(y.min) or 0
    local maxV = tonumber(y.max) or minV
    local prob = tonumber(y.prob) or 0
    return ((minV + maxV) / 2) * prob
end

local function CalculateInputEV(inputItemID, def)
    local ev = 0
    local hasAnyPrice = false
    for _, y in ipairs(def.yields or {}) do
        local outPrice = GetPriceByItemID(y.itemID)
        if outPrice and outPrice > 0 then
            hasAnyPrice = true
            ev = ev + (ExpectedYield(y) * outPrice)
        end
    end
    if not hasAnyPrice then
        return nil
    end
    return ev
end

function MarketSync.GetProcessingTargets()
    local seen = {}
    local out = {}
    for _, def in pairs(MarketSync.ProcessingData or {}) do
        for _, y in ipairs(def.yields or {}) do
            if y.itemID and not seen[y.itemID] then
                seen[y.itemID] = true
                table.insert(out, {
                    itemID = y.itemID,
                    name = GetItemName(y.itemID) or ("Item " .. tostring(y.itemID)),
                })
            end
        end
    end
    table.sort(out, function(a, b) return (a.name or "") < (b.name or "") end)
    return out
end

function MarketSync.FindArbitrageByTarget(targetItemID, marginPercent)
    local targetPrice = GetPriceByItemID(targetItemID)
    if not targetPrice or targetPrice <= 0 then
        return {}
    end

    local margin = tonumber(marginPercent) or 0
    local marginMult = math.max(0, 1 - (margin / 100))
    local results = {}

    for inputItemID, def in pairs(MarketSync.ProcessingData or {}) do
        local expectedTarget = 0
        for _, y in ipairs(def.yields or {}) do
            if tonumber(y.itemID) == tonumber(targetItemID) then
                expectedTarget = expectedTarget + ExpectedYield(y)
            end
        end
        if expectedTarget > 0 then
            local stackSize = tonumber(def.stackSize) or 1
            local maxBuyPerStack = targetPrice * expectedTarget * marginMult
            local maxBuyPerUnit = math.floor(maxBuyPerStack / math.max(1, stackSize))
            local livePrice = GetPriceByItemID(inputItemID) or 0
            table.insert(results, {
                inputItemID = inputItemID,
                inputName = GetItemName(inputItemID) or ("Item " .. tostring(inputItemID)),
                processType = def.type,
                stackSize = stackSize,
                targetItemID = targetItemID,
                targetName = GetItemName(targetItemID) or ("Item " .. tostring(targetItemID)),
                targetPrice = targetPrice,
                expectedTarget = expectedTarget,
                maxBuyPerUnit = maxBuyPerUnit,
                maxBuyPerStack = math.floor(maxBuyPerStack),
                livePrice = livePrice,
                profitable = (livePrice > 0 and livePrice <= maxBuyPerUnit),
            })
        end
    end

    table.sort(results, function(a, b)
        if (a.profitable and not b.profitable) then return true end
        if (b.profitable and not a.profitable) then return false end
        return (a.maxBuyPerUnit or 0) > (b.maxBuyPerUnit or 0)
    end)

    return results
end

function MarketSync.FindArbitrageByProcess(processType, marginPercent)
    local margin = tonumber(marginPercent) or 0
    local marginMult = math.max(0, 1 - (margin / 100))
    local results = {}

    for inputItemID, def in pairs(MarketSync.ProcessingData or {}) do
        if not processType or def.type == processType then
            local evPerAction = CalculateInputEV(inputItemID, def)
            if evPerAction and evPerAction > 0 then
                local stackSize = tonumber(def.stackSize) or 1
                local evPerUnit = evPerAction / math.max(1, stackSize)
                local maxBuyPerUnit = math.floor(evPerUnit * marginMult)
                local livePrice = GetPriceByItemID(inputItemID) or 0
                table.insert(results, {
                    inputItemID = inputItemID,
                    inputName = GetItemName(inputItemID) or ("Item " .. tostring(inputItemID)),
                    processType = def.type,
                    stackSize = stackSize,
                    evPerAction = math.floor(evPerAction),
                    evPerUnit = math.floor(evPerUnit),
                    maxBuyPerUnit = maxBuyPerUnit,
                    livePrice = livePrice,
                    profitable = (livePrice > 0 and livePrice <= maxBuyPerUnit),
                })
            end
        end
    end

    table.sort(results, function(a, b)
        if (a.profitable and not b.profitable) then return true end
        if (b.profitable and not a.profitable) then return false end
        return (a.evPerUnit or 0) > (b.evPerUnit or 0)
    end)
    return results
end

function MarketSync.ExportArbitrageToAuctionator(results, listName)
    if not Auctionator or not Auctionator.API or not Auctionator.API.v1 then
        return false, "Auctionator API unavailable"
    end
    if not results or #results == 0 then
        return false, "No results to export"
    end

    local exportName = listName or ("MarketSync Arbitrage " .. date("%m/%d %H:%M"))
    local searchStrings = {}

    for _, r in ipairs(results) do
        if r.inputItemID and (r.maxBuyPerUnit or 0) > 0 then
            local name = GetItemName(r.inputItemID)
            if name then
                local term = {
                    searchString = name,
                    isExact = true,
                    maxPrice = math.max(1, math.floor(r.maxBuyPerUnit)),
                }
                local okConv, searchString = pcall(Auctionator.API.v1.ConvertToSearchString, CALLER_ID, term)
                if okConv and type(searchString) == "string" and searchString ~= "" then
                    table.insert(searchStrings, searchString)
                else
                    table.insert(searchStrings, '"' .. name .. '"')
                end
            end
        end
    end

    if #searchStrings == 0 then
        return false, "No valid export entries"
    end

    local okCreate, err = pcall(Auctionator.API.v1.CreateShoppingList, CALLER_ID, exportName, searchStrings)
    if not okCreate then
        return false, tostring(err)
    end
    return true, #searchStrings
end

function MarketSync.FindProfitableCrafts(professionName, minMarginCopper)
    local recipes = MarketSync.CraftingData and MarketSync.CraftingData[professionName]
    if not recipes then return {} end

    local minMargin = tonumber(minMarginCopper) or 0
    local out = {}

    for _, recipe in ipairs(recipes) do
        local outputPrice = GetPriceByItemID(recipe.outputItemID) or 0
        if outputPrice > 0 then
            local craftCost = 0
            local hasMissing = false
            for _, mat in ipairs(recipe.mats or {}) do
                local matPrice = GetPriceByItemID(mat.itemID)
                if not matPrice or matPrice <= 0 then
                    hasMissing = true
                    break
                end
                craftCost = craftCost + (matPrice * (mat.qty or 1))
            end
            if not hasMissing then
                local outputQty = tonumber(recipe.outputQty) or 1
                local revenue = math.floor(outputPrice * outputQty * 0.95) -- AH cut
                local margin = revenue - craftCost
                if margin >= minMargin then
                    table.insert(out, {
                        profession = professionName,
                        recipeName = recipe.name or ("Item " .. tostring(recipe.outputItemID)),
                        outputItemID = recipe.outputItemID,
                        outputName = GetItemName(recipe.outputItemID) or ("Item " .. tostring(recipe.outputItemID)),
                        craftCost = craftCost,
                        revenue = revenue,
                        margin = margin,
                        mats = recipe.mats,
                    })
                end
            end
        end
    end

    table.sort(out, function(a, b) return (a.margin or 0) > (b.margin or 0) end)
    return out
end

function MarketSync.ExportCraftMatsToAuctionator(craftResults, listName)
    if not Auctionator or not Auctionator.API or not Auctionator.API.v1 then
        return false, "Auctionator API unavailable"
    end
    if not craftResults or #craftResults == 0 then
        return false, "No craft data to export"
    end

    local mats = {}
    for _, c in ipairs(craftResults) do
        for _, mat in ipairs(c.mats or {}) do
            mats[mat.itemID] = true
        end
    end

    local searchStrings = {}
    for itemID in pairs(mats) do
        local name = GetItemName(itemID)
        if name then
            table.insert(searchStrings, '"' .. name .. '"')
        end
    end

    if #searchStrings == 0 then
        return false, "No materials resolved for export"
    end

    local exportName = listName or ("MarketSync Craft Mats " .. date("%m/%d %H:%M"))
    local okCreate, err = pcall(Auctionator.API.v1.CreateShoppingList, CALLER_ID, exportName, searchStrings)
    if not okCreate then
        return false, tostring(err)
    end

    return true, #searchStrings
end
